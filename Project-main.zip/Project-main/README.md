# Project
# Classification Project
# Business Problem:
To create a Classification model which can predict whether company will go bankrupt or not based on given features and make strategies accordingly  to avoid its bankruptcy
# Objective:
To predict bankruptcy or non-bankruptcy with the help of model which gives  probability that a business goes bankrupt from different features.
